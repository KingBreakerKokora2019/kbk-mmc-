***ReCaptcha2***

Hoster müssen vor der Nutzung in den Index-Seiten Einstellungen aktiviert werden 

**MyJdownloader**

Auf der Hompage von MyJdownloader ein Benutzerkonto erstellen (auch Wegwerf Email möglich)

Android App (MyJdownloader) herunterladen

https://apkpure.com/de/myjdownloader-remote-official/org.appwork.myjdandroid

Auf der MyJdownloader Homepage kann auch eine PC Software herunter geladen werden, wenn Ihr
angemeldet seid

MyJdownloader Daten in Lastship / Recaptcher2 / MyJdownloader eintragen und im App bzw. in der PC
Software

In Lastship einen Film / Serie suchen, Anbieter/Hoster wählen

Dann kommt ein Dialog, dass Captcha in MyJdownloader gelöst werden muss

App öffnen, Captcha lösen -> Stream startet

Es wird nicht immer sofort das “unsolved captcha” angezeigt

Da hilft auf “Refresh JDownloaders” klicken

Dann steht da “unsolved captcha”, hier auf “show” klicken, dann “Ich bin kein Roboter” und das Captcha lösen
Es kann sein dass noch ein 2. zu lösen ist

Das Captcha kann von überall gelöst werden, man muss nichteinmal im selben Netzwerk sein

Die Authetifizierung erfolgt über den Benutzernamen und das Passwort

Wenn ihr vor dem Captcha lösen, in der MyJdownloader App, “Clear All Cookies” auswählt, müsst ihr nicht
so viele Captchas lösen

Die iOS App geht nicht, der Entwickler wurde informiert

Dafür geht es im Browser (Theoretisch)

Es kann dafür einfach der Noxplayer am PC installieren werden und dann die Android App.Geht super

**Captcha9KW**

Eine weitere Möglichkeit Captcha zu lösen ist über die Webseite https://www.9kw.eu/index.html

Hier ein Benutzerkonto anlegen (kann auch Wegwerf E-Mail sein), und Anmelden

*Das Prinzip/die Funktion dieser Seite ist wie folgt:*

Es besteht zum einen die Möglichkeit nur die Eigenen Captcha zu lösen und zum anderen können Captcha
von fremden Usern gelöst werden

Mit dem Lösen Fremder Captcha bekommt man Guthaben gutgeschrieben

Dieses Guthaben wird benötigt, wenn man später nicht selbst seine Eigenen Captcha lösen möchten, denn
dann wird das von anderen Usern erledigt

Nach dem Login ist rechts ein Feld mit Daten zu sehen

Über dieses Daten Feld hat man Zugriff auf den API-Key (welcher in Lastship eingetragen werden
muss)und die Einstellungen

1. Klick auf API Key
Nun befindet man sich in der API Verwaltung
Zu sehen sind hier einige (nicht unbedingt nötige Infos) und der API

2. Diesen API kopieren und in Lastship unter Recaptcha2/Captcha9KW eintragen

Soll der API Key einmal geändert/erneuert werden, dann auf dieser Seite Neuen Schlüssel erzeugen klicken

Eigene Captcha lösen (Selfsolve) kann in Lastship aktivieren werden und muss zusätzlich auf der Webseite eingestellt werden

Wenn das gemacht wurde, dann bekommt man nicht beliebige Captcha zum Lösen, sondern nur die Eigenen

*Auf der Webseite ist es unter:*

DATEN - Einstellungen - Profieinstellungen (Haken im Kästchen machen, Meldung mit OK bestätigen) -
Sandbox zum Einstellen

Sandbox: JA
Type: Eigene
Selbst lösen bei Captchas automatisch setzen: JA

Wenn Eigene Captcha lösen (SelfSolve) in Lastship aktiviert ist, dann muss man selbst die Captcha lösen, in
der App oder in einem 9kw Client

Die Downloads dafür befinden sich auf der Webseite unter Plugins, Softwareliste bzw. Mobile Apps

Der API-Key von der Webseite muss immer in den Apps oder PC Client eingetragen werden!!

Die Software für PC, Download Link, funktioniert recht gut, die für Android weniger, z.B. CaptchaToGo aus
dem GooglePlaystore

Ist Eigene Captcha lösen deaktiviert, dann wird es von irgendjemand gemacht

Das kann aber schon mal 2-3 Minuten dauern

*Gibt die Captcha9KW einen Fehler zurück, wenn Captcha nicht gelöst wird?*

Nein gibt keinen Fehler und auch keinen Timeout

In Lastship – Recaptcha2 Einstellungen Timout auf 300 Sekunden stellen und dann einfach mal warten

*Beispiel was die Warteliste auf der 9kw Webseite bedeutet:*

Zu finden ist die Warteliste auf der Webseite am rechten Rand / mehr klicken

Warteliste: 92 (<299s: 5 - >299s: 87)
Das heißt 5 Captcha werden voraussichtlich in den nächsten 299s gelöst, der Rest danach

!!Je mehr User Online sind um Captcha zu lösen, umso kürzer die Wartezeit!!

*ERKLÄRUNG zu Guthaben:*

Guthaben (Credits) bedeutet, andere lösen für dich das Captcha

Es gibt 2 Möglichkeiten
1.) Andere lösen deine Captchas --> du braucht Guthaben
2.) Du löst deine eigenen Captchas -> Eigene Captcha lösen Option muss aktiviert werden in Lastship und
im App/Client

Punkt 18 9KW FAQ erklärt Eigene Captcha lösen (selfsolve): https://www.9kw.eu/faq.html

Das Lösen von Captcha direkt auf der Webseite funktioniert leider nicht

*Guthaben verdienen:*

Guthaben (Punkte) kann man sich wie verdienen in dem man Captcha von anderen Usern löst, wie schon am Anfang dieser FAQ beschrieben

Dazu muss aber in der Sandbox (siehe weiter oben in dieser Anleitung), Type: ALLE eingestellt werden

Dann den PC Client Starten (muss nicht installiert werden), API Key ganz oben eintragen

Rechts sind 2 Kästchen zu sehen, Typ und Notification

Bei Notification wird gewählt welche Art von Captcha angezeigt/gelöst werden sollen

Bei Notification wird nichts verändert, hier wird das Lösen der Captcha durch Klick auf Start gestartet

Bei Credits ist das gesammelte Guthaben zu sehen

Für jedes gelöste Captcha wird Guthaben abgezogen, ohne Guthaben kein Captcha lösen möglich
